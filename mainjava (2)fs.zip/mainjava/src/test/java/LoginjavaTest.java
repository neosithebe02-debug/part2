/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


import com.mycompany.mainjava.Loginjava;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginjavaTest {

    private Loginjava valid() {
        return new Loginjava("kyl_1", "Ch&&sec@ke99!", "+27838969876", "Kyle", "Smith");
    }

    @Test
    public void usernameCorrectlyFormatted() { assertTrue(valid().checkUserName()); }

    @Test
    public void usernameIncorrectlyFormatted() {
        assertFalse(new Loginjava("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838969876", "Kyle", "Smith").checkUserName());
    }

    @Test
    public void passwordMeetsComplexity() { assertTrue(valid().checkPasswordComplexity()); }

    @Test
    public void passwordFailsComplexity() {
        assertFalse(new Loginjava("kyl_1", "password", "+27838969876", "Kyle", "Smith").checkPasswordComplexity());
    }

    @Test
    public void cellNumberCorrectlyFormatted() { assertTrue(valid().checkCellPhoneNumber()); }

    @Test
    public void cellNumberIncorrectlyFormatted() {
        assertFalse(new Loginjava("kyl_1", "Ch&&sec@ke99!", "08966553", "Kyle", "Smith").checkCellPhoneNumber());
    }

    @Test
    public void loginSuccessful() { assertTrue(valid().loginUser("kyl_1", "Ch&&sec@ke99!")); }

    @Test
    public void loginFailed() { assertFalse(valid().loginUser("kyl_1", "WrongPassword1!")); }
}


