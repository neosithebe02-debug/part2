/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



package com.mycompany.mainjava;

import com.mycompany.mainjava.Message;
import com.mycompany.mainjava.MessageManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/** Uses the five test-data messages from the project brief. */
public class MessageManagerTest {

    private MessageManager manager;

    @BeforeEach
    public void setUp(@TempDir Path dir) throws IOException {
        manager = new MessageManager(dir.resolve("storedMessages.json"));
        manager.loadTestData("Kyle Smith");
    }

    @Test
    public void sentMessagesArrayCorrectlyPopulated() {
        assertEquals(2, manager.getSentMessages().size());
        assertEquals("Did you get the cake?\nIt is dinner time!", manager.displaySentMessages());
    }

    @Test
    public void disregardedMessagesArrayCorrectlyPopulated() {
        assertEquals(1, manager.getDisregardedMessages().size());
        assertEquals("Yohoooo, I am at your gate.", manager.getDisregardedMessages().get(0).getText());
    }

    @Test
    public void storedMessagesReadFromJson() {
        assertEquals(2, manager.getStoredMessages().size());
        assertEquals("+27838884567", manager.getStoredMessages().get(0).getRecipient());
    }

    @Test
    public void hashAndIdArraysPopulated() {
        assertEquals(5, manager.getMessageHashes().size());
        assertEquals(5, manager.getMessageIDs().size());
        assertEquals("10:0:DIDCAKE", manager.getMessageHashes().get(0));
    }

    @Test
    public void displayLongestMessage() {
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                manager.displayLongestMessage());
    }

    @Test
    public void searchForMessageId() {
        String result = manager.searchByMessageId("4000000004");
        assertTrue(result.contains("0838884567"));
        assertTrue(result.contains("It is dinner time!"));
    }

    @Test
    public void searchMessageIdNotFound() {
        assertTrue(manager.searchByMessageId("9999999999").startsWith("No message found"));
    }

    @Test
    public void searchAllMessagesForRecipient() {
        assertEquals("Where are you? You are late! I have asked you to be on time.\n"
                        + "Ok, I am leaving without you.",
                manager.searchByRecipient("+27838884567"));
    }

    @Test
    public void deleteMessageUsingHash() {
        String hash = manager.getMessageHashes().get(1);   // Test Data Message 2
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.",
                manager.deleteByHash(hash));
        assertEquals(1, manager.getStoredMessages().size());
        assertEquals(4, manager.getMessageIDs().size());
    }

    @Test
    public void deletePersistsToJson() throws IOException {
        manager.deleteByHash(manager.getMessageHashes().get(1));
        assertEquals(1, manager.readJson().size());
    }

    @Test
    public void deleteUnknownHash() {
        assertTrue(manager.deleteByHash("00:0:NOPE").startsWith("No message found"));
    }

    @Test
    public void displayReportShowsHashRecipientAndMessage() {
        String report = manager.displayReport();
        assertTrue(report.contains("Message Hash: 20:1:WHERETIME"));
        assertTrue(report.contains("Recipient:    +27838884567"));
        assertTrue(report.contains("Message:      Ok, I am leaving without you."));
    }

    @Test
    public void senderAndRecipientDisplayed() {
        assertTrue(manager.displaySenderAndRecipient().contains("Sender: Kyle Smith | Recipient: +27838884567"));
    }

    @Test
    public void messageValidation() {
        assertTrue(Message.checkRecipientCell("+27838884567"));
        assertFalse(Message.checkRecipientCell("0838884567"));
        assertTrue(Message.checkMessageLength("short"));
        assertFalse(Message.checkMessageLength("x".repeat(251)));
    }
}
