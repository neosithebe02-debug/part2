/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjava;

/**
 * A single chat message (Part 2 entity, reused by Part 3).
 */
public class Message {

    public static final String SENT = "Sent";
    public static final String STORED = "Stored";
    public static final String DISREGARD = "Disregard";

    private final String messageId;
    private final int messageNumber;
    private final String sender;
    private final String recipient;
    private final String text;
    private final String flag;
    private final String hash;

    public Message(String messageId, int messageNumber, String sender,
                   String recipient, String text, String flag) {
        this.messageId = messageId;
        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.text = text;
        this.flag = flag;
        this.hash = createMessageHash();
    }

    /** Message ID must be no more than 10 characters (digits). */
    public boolean checkMessageID() {
        return messageId != null && messageId.length() <= 10 && messageId.matches("\\d+");
    }

    /** Recipient: international code (e.g. +27) followed by no more than 10 digits. */
    public static boolean checkRecipientCell(String cell) {
        return cell != null && cell.matches("^\\+\\d{1,3}\\d{1,10}$");
    }

    /** Message may be at most 250 characters. */
    public static boolean checkMessageLength(String text) {
        return text != null && text.length() <= 250;
    }

    /**
     * Hash = first two digits of ID : message number : FIRSTWORDLASTWORD (upper case).
     * Punctuation is stripped from the first/last word.
     */
    public final String createMessageHash() {
        String[] words = text.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        String prefix = messageId.length() >= 2 ? messageId.substring(0, 2) : messageId;
        return (prefix + ":" + messageNumber + ":" + first + last).toUpperCase();
    }

    public String getMessageId() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getText() { return text; }
    public String getFlag() { return flag; }
    public String getHash() { return hash; }

    /** Full details used by the report. */
    public String details() {
        return "Message Hash: " + hash + "\n"
                + "Message ID:   " + messageId + "\n"
                + "Sender:       " + sender + "\n"
                + "Recipient:    " + recipient + "\n"
                + "Message:      " + text + "\n"
                + "Flag:         " + flag;
    }
}
