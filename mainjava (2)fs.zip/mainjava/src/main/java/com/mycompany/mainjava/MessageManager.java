/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainjava;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Holds the five arrays required by Part 3 and all operations on them.
 * Every operation returns a String so it can be unit tested and printed by the menu.
 */
public class MessageManager {

    // --- The five required arrays (populated at run time, nothing hard-coded) ---
    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> disregardedMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();
    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIDs = new ArrayList<>();
    // every message, same order as messageIDs / messageHashes (used for ID lookups)
    private final List<Message> allMessages = new ArrayList<>();

    private final Path jsonFile;
    private int messageCounter = 0;

    public MessageManager(Path jsonFile) {
        this.jsonFile = jsonFile;
    }

    // ------------------------------------------------------------------ populate

    /** Adds a message to the correct arrays according to its flag. */
    public Message addMessage(String messageId, String sender, String recipient,
                              String text, String flag) {
        Message m = new Message(messageId, messageCounter++, sender, recipient, text, flag);
        register(m);
        if (Message.STORED.equalsIgnoreCase(flag)) {
            storedMessages.add(m);
        } else if (Message.SENT.equalsIgnoreCase(flag)) {
            sentMessages.add(m);
        } else {
            disregardedMessages.add(m);
        }
        return m;
    }

    private void register(Message m) {
        allMessages.add(m);
        messageIDs.add(m.getMessageId());
        messageHashes.add(m.getHash());
    }

    /** Generates a random 10 digit message ID. */
    public static String generateMessageId() {
        StringBuilder sb = new StringBuilder();
        java.util.Random r = new java.util.Random();
        for (int i = 0; i < 10; i++) {
            sb.append(r.nextInt(10));
        }
        return sb.toString();
    }

    /**
     * Loads the five test-data messages from the brief. Stored messages are written to the
     * JSON file and the stored array is then read back from that file.
     */
    public void loadTestData(String sender) throws IOException {
        addMessage("1000000001", sender, "+27834557896", "Did you get the cake?", Message.SENT);
        addMessage("2000000002", sender, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", Message.STORED);
        addMessage("3000000003", sender, "+27834484567", "Yohoooo, I am at your gate.", Message.DISREGARD);
        addMessage("4000000004", sender, "0838884567", "It is dinner time!", Message.SENT);
        addMessage("5000000005", sender, "+27838884567", "Ok, I am leaving without you.", Message.STORED);

        // persist the stored ones, then re-read them into the stored array from JSON
        List<Message> toStore = new ArrayList<>(storedMessages);
        storedMessages.clear();
        writeJson(toStore);
        storedMessages.addAll(readJson());
    }

    // ---------------------------------------------------------------------- JSON

    /** Writes the messages to the JSON file as an array of objects. */
    public void writeJson(List<Message> messages) throws IOException {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < messages.size(); i++) {
            Message m = messages.get(i);
            sb.append("  {\n")
              .append("    \"messageId\": ").append(q(m.getMessageId())).append(",\n")
              .append("    \"messageNumber\": ").append(m.getMessageNumber()).append(",\n")
              .append("    \"sender\": ").append(q(m.getSender())).append(",\n")
              .append("    \"recipient\": ").append(q(m.getRecipient())).append(",\n")
              .append("    \"text\": ").append(q(m.getText())).append(",\n")
              .append("    \"flag\": ").append(q(m.getFlag())).append("\n")
              .append("  }").append(i < messages.size() - 1 ? "," : "").append("\n");
        }
        sb.append("]\n");
        Files.write(jsonFile, sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    /** Quotes and escapes a string for JSON. */
    private static String q(String v) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : v.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default: sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    /** Reads the JSON file back into Message objects (simple parser for our own format). */
    public List<Message> readJson() throws IOException {
        List<Message> list = new ArrayList<>();
        if (!Files.exists(jsonFile)) {
            return list;
        }
        String json = new String(Files.readAllBytes(jsonFile), StandardCharsets.UTF_8);
        java.util.Map<String, String> fields = null;
        int i = 0;
        while (i < json.length()) {
            char c = json.charAt(i);
            if (c == '{') {
                fields = new java.util.HashMap<>();
                i++;
            } else if (c == '}') {
                if (fields != null) {
                    list.add(new Message(fields.get("messageId"),
                            Integer.parseInt(fields.get("messageNumber")),
                            fields.get("sender"), fields.get("recipient"),
                            fields.get("text"), fields.get("flag")));
                }
                fields = null;
                i++;
            } else if (c == '"' && fields != null) {
                int[] pos = {i};
                String key = readString(json, pos);
                i = pos[0];
                while (json.charAt(i) != ':') i++;
                i++;
                while (Character.isWhitespace(json.charAt(i))) i++;
                if (json.charAt(i) == '"') {
                    pos[0] = i;
                    fields.put(key, readString(json, pos));
                    i = pos[0];
                } else {
                    int end = i;
                    while (end < json.length() && ",}\n\r ".indexOf(json.charAt(end)) < 0) end++;
                    fields.put(key, json.substring(i, end));
                    i = end;
                }
            } else {
                i++;
            }
        }
        return list;
    }

    /** Reads a quoted JSON string starting at pos[0]; leaves pos[0] after the closing quote. */
    private static String readString(String json, int[] pos) {
        StringBuilder sb = new StringBuilder();
        int i = pos[0] + 1;
        while (json.charAt(i) != '"') {
            char c = json.charAt(i);
            if (c == '\\') {
                i++;
                char e = json.charAt(i);
                switch (e) {
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    default: sb.append(e);
                }
            } else {
                sb.append(c);
            }
            i++;
        }
        pos[0] = i + 1;
        return sb.toString();
    }

    /** Appends a message to the JSON file (used when the user chooses "Store"). */
    public void storeToJson(Message m) throws IOException {
        List<Message> existing = readJson();
        existing.add(m);
        writeJson(existing);
    }

    // ------------------------------------------------ Stored Messages menu (a - f)

    /** a. Sender and recipient of all stored messages. */
    public String displaySenderAndRecipient() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Sender: ").append(m.getSender())
              .append(" | Recipient: ").append(m.getRecipient()).append("\n");
        }
        return sb.toString().trim();
    }

    /** b. Longest stored message. */
    public String displayLongestMessage() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }
        Message longest = storedMessages.get(0);
        for (Message m : storedMessages) {
            if (m.getText().length() > longest.getText().length()) {
                longest = m;
            }
        }
        return longest.getText();
    }

    /** c. Search by message ID, returning recipient and message. */
    public String searchByMessageId(String id) {
        int index = messageIDs.indexOf(id);
        if (index < 0) {
            return "No message found with ID " + id + ".";
        }
        Message m = allMessages.get(index);
        return "Recipient: " + m.getRecipient() + "\nMessage: " + m.getText();
    }

    /** d. All stored messages for a recipient. */
    public String searchByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            if (m.getRecipient().equals(recipient)) {
                sb.append(m.getText()).append("\n");
            }
        }
        return sb.length() == 0 ? "No stored messages found for " + recipient + "."
                                : sb.toString().trim();
    }

    /** e. Delete a stored message by hash. */
    public String deleteByHash(String hash) {
        int index = messageHashes.indexOf(hash);
        if (index < 0) {
            return "No message found with hash " + hash + ".";
        }
        Message m = allMessages.get(index);
        allMessages.remove(index);
        messageIDs.remove(index);
        messageHashes.remove(index);
        // match on ID: stored messages are fresh objects read back from the JSON file
        String id = m.getMessageId();
        storedMessages.removeIf(x -> x.getMessageId().equals(id));
        sentMessages.removeIf(x -> x.getMessageId().equals(id));
        disregardedMessages.removeIf(x -> x.getMessageId().equals(id));
        try {
            writeJson(new ArrayList<>(storedMessages));
        } catch (IOException e) {
            return "Message deleted from memory but the JSON file could not be updated: "
                    + e.getMessage();
        }
        return "Message: \"" + m.getText() + "\" successfully deleted.";
    }

    /** f. Report listing the full details of all stored messages. */
    public String displayReport() {
        if (storedMessages.isEmpty()) {
            return "There are no stored messages.";
        }
        StringBuilder sb = new StringBuilder("===== STORED MESSAGES REPORT =====\n");
        int n = 1;
        for (Message m : storedMessages) {
            sb.append("\n--- Message ").append(n++).append(" ---\n").append(m.details()).append("\n");
        }
        return sb.toString().trim();
    }

    /** Text of every sent message (used by the Sent array test). */
    public String displaySentMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append(m.getText()).append("\n");
        }
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------ getters

    public List<Message> getSentMessages() { return sentMessages; }
    public List<Message> getDisregardedMessages() { return disregardedMessages; }
    public List<Message> getStoredMessages() { return storedMessages; }
    public List<String> getMessageHashes() { return messageHashes; }
    public List<String> getMessageIDs() { return messageIDs; }
}
