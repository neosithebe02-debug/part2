/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mainjava;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 * Chat app - Part 1 (register/login), Part 2 (send messages) and
 * Part 3 (arrays, stored messages menu, JSON).
 */
public class Mainjava {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("===== CHAT APP =====");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();
        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();
        System.out.print("Enter username (must contain '_' and be no more than 5 characters): ");
        String username = input.nextLine();
        System.out.print("Enter password (minimum 8 characters, with at least 1 uppercase, 1 number, and 1 special character): ");
        String password = input.nextLine();
        System.out.print("Enter South African cell phone number (+27XXXXXXXXX): ");
        String cellPhone = input.nextLine();

        Loginjava user = new Loginjava(username, password, cellPhone, firstName, lastName);

        System.out.println();
        System.out.println(user.registerUser());

        if (user.checkUserName() && user.checkPasswordComplexity() && user.checkCellPhoneNumber()) {
            System.out.println();
            System.out.println("===== Login =====");
            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();
            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            boolean ok = user.loginUser(loginUsername, loginPassword);
            System.out.println(user.returnLoginStatus(ok));

            if (ok) {
                runMenu(input, firstName + " " + lastName);
            }
        }
        input.close();
    }

    private static void runMenu(Scanner input, String senderName) {
        MessageManager manager = new MessageManager(Paths.get("storedMessages.json"));
        try {
            manager.loadTestData(senderName);
        } catch (IOException e) {
            System.out.println("Could not load test data: " + e.getMessage());
        }

        System.out.println("\nWelcome to QuickChat.");
        boolean running = true;
        while (running) {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Choose an option: ");
            String choice = input.nextLine().trim();

            switch (choice) {
                case "1": sendMessages(input, manager, senderName); break;
                case "2": System.out.println("Coming soon."); break;
                case "3": System.out.println("Goodbye."); running = false; break;
                case "4": storedMessagesMenu(input, manager); break;
                default: System.out.println("Invalid option, please try again.");
            }
        }
    }

    private static void sendMessages(Scanner input, MessageManager manager, String sender) {
        System.out.print("How many messages would you like to enter? ");
        int count;
        try {
            count = Integer.parseInt(input.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Please enter a number.");
            return;
        }

        for (int i = 0; i < count; i++) {
            System.out.println("\n--- Message " + (i + 1) + " of " + count + " ---");
            System.out.print("Recipient cell number (with international code): ");
            String recipient = input.nextLine().trim();
            if (!Message.checkRecipientCell(recipient)) {
                System.out.println("Cell phone number is incorrectly formatted or does not contain an international code.");
                i--;
                continue;
            }
            System.out.print("Message (max 250 characters): ");
            String text = input.nextLine();
            if (!Message.checkMessageLength(text)) {
                System.out.println("Message exceeds 250 characters by " + (text.length() - 250)
                        + ", please reduce size.");
                i--;
                continue;
            }
            if (text.trim().isEmpty()) {
                System.out.println("Message cannot be empty.");
                i--;
                continue;
            }

            System.out.println("1) Send   2) Disregard   3) Store to send later");
            System.out.print("Choose: ");
            String flag;
            switch (input.nextLine().trim()) {
                case "1": flag = Message.SENT; break;
                case "3": flag = Message.STORED; break;
                default: flag = Message.DISREGARD;
            }

            Message m = manager.addMessage(MessageManager.generateMessageId(), sender, recipient, text, flag);
            System.out.println("Message " + (flag.equals(Message.SENT) ? "sent."
                    : flag.equals(Message.STORED) ? "stored." : "disregarded."));
            System.out.println(m.details());
            if (flag.equals(Message.STORED)) {
                try {
                    manager.storeToJson(m);
                } catch (IOException e) {
                    System.out.println("Could not write to JSON file: " + e.getMessage());
                }
            }
        }
    }

    private static void storedMessagesMenu(Scanner input, MessageManager manager) {
        boolean back = false;
        while (!back) {
            System.out.println("\n===== STORED MESSAGES =====");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search for a message ID");
            System.out.println("d) Search for all messages stored for a recipient");
            System.out.println("e) Delete a message using its message hash");
            System.out.println("f) Display a report of all stored messages");
            System.out.println("g) Back to main menu");
            System.out.print("Choose an option: ");

            switch (input.nextLine().trim().toLowerCase()) {
                case "a": System.out.println(manager.displaySenderAndRecipient()); break;
                case "b": System.out.println(manager.displayLongestMessage()); break;
                case "c":
                    System.out.print("Enter message ID: ");
                    System.out.println(manager.searchByMessageId(input.nextLine().trim()));
                    break;
                case "d":
                    System.out.print("Enter recipient: ");
                    System.out.println(manager.searchByRecipient(input.nextLine().trim()));
                    break;
                case "e":
                    System.out.print("Enter message hash: ");
                    System.out.println(manager.deleteByHash(input.nextLine().trim().toUpperCase()));
                    break;
                case "f": System.out.println(manager.displayReport()); break;
                case "g": back = true; break;
                default: System.out.println("Invalid option, please try again.");
            }
        }
    }
}
